import React, { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { interactiveCertificationsCatalog, InteractiveCertification } from "@/data/interactiveCertificationCatalog";
import { getCertificationStats, readAnswerHistory, readCompletionHistory, saveCompletion, type AnswerHistory, type CompletionHistory } from "@/data/certificationProgress";
import { useAuth } from "@/_core/hooks/useAuth";
import { Award, ArrowRight, CheckCircle2, Download, ExternalLink, Eye, Filter, Linkedin, RotateCcw, Search, ShieldCheck, Sparkles, Trophy, Twitter, UserRound } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { recordStudyActivity } from "@/data/profile";
import { playInterfaceSound } from "@/hooks/useInterfaceSound";

type Celebration = { title: string; description: string; kind: "badge" | "perfect" };

function createCertificatePdf(cert: InteractiveCertification, userName: string, scorePercentage: number) {
  if (typeof window === "undefined") return;
  const popup = window.open("", "_blank", "width=1024,height=768");
  if (!popup) return;
  const completionDate = new Date().toLocaleDateString("pt-BR", { dateStyle: "long" });
  const safeName = userName.replace(/[<>]/g, "");
  const safeTitle = cert.title.replace(/[<>]/g, "");
  popup.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8" /><title>Certificado IA Academy - ${safeTitle}</title><style>
    @page{size:A4 landscape;margin:0}*{box-sizing:border-box}body{margin:0;background:#eef2ff;color:#172033;font-family:Inter,Arial,sans-serif}.certificate{width:297mm;min-height:210mm;margin:0 auto;padding:24mm;display:flex;align-items:center;justify-content:center}.frame{width:100%;min-height:155mm;border:2px solid #5b5cf0;border-radius:28px;background:#fff;padding:22mm;text-align:center;position:relative;box-shadow:0 12px 40px rgba(36,42,96,.14)}.eyebrow{color:#5356d9;text-transform:uppercase;letter-spacing:.2em;font-weight:700;font-size:12px}.mark{font-size:28px;font-weight:800;margin:16px 0}.mark span{color:#5b5cf0}.title{font-family:Georgia,serif;font-size:40px;margin:20px 0 10px}.name{font-size:34px;font-weight:800;color:#27304f;margin:24px 0 14px}.description{font-size:15px;color:#5e6780;margin:0 auto;max-width:680px;line-height:1.6}.score{display:inline-block;margin-top:22px;padding:10px 18px;border-radius:999px;background:#eef0ff;color:#4246bf;font-weight:800}.footer{display:flex;justify-content:space-between;position:absolute;left:22mm;right:22mm;bottom:14mm;color:#6b7280;font-size:12px}.seal{position:absolute;right:20mm;top:16mm;width:64px;height:64px;border:2px solid #f2b84b;border-radius:50%;display:grid;place-items:center;color:#b77b0a;font-weight:800;font-size:11px}@media print{body{background:#fff}.certificate{margin:0}.frame{box-shadow:none}}
  </style></head><body><main class="certificate"><section class="frame"><div class="seal">IA<br/>ACADEMY</div><div class="eyebrow">Certificado de conclusão · simulador de estudos</div><div class="mark">IA <span>Academy</span></div><h1 class="title">Certificado de Conclusão</h1><p class="description">Certificamos que</p><div class="name">${safeName}</div><p class="description">concluiu o simulador de estudos <strong>${safeTitle}</strong>, demonstrando ${scorePercentage}% de aproveitamento no conteúdo avaliado pela IA Academy.</p><div class="score">Aproveitamento: ${scorePercentage}%</div><div class="footer"><span>Emitido em ${completionDate}</span><span>Documento de estudo · Não substitui a certificação oficial do provedor</span></div></section></main><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),250));</script></body></html>`);
  popup.document.close();
}

export default function InteractiveCertifications() {
  const { user } = useAuth();
  const [selectedCert, setSelectedCert] = useState<InteractiveCertification>(interactiveCertificationsCatalog[0]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answerHistory, setAnswerHistory] = useState<AnswerHistory>(() => readAnswerHistory());
  const [completionHistory, setCompletionHistory] = useState<CompletionHistory>(() => readCompletionHistory());
  const [showResults, setShowResults] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [levelFilter, setLevelFilter] = useState("todos");
  const [issuerFilter, setIssuerFilter] = useState("todos");
  const [celebration, setCelebration] = useState<Celebration | null>(null);
  const [certificatePreviewOpen, setCertificatePreviewOpen] = useState(false);

  const selectedAnswers = answerHistory[selectedCert.id] ?? {};
  const currentQuestion = selectedCert.quiz[currentQuestionIndex];
  const selectedStats = getCertificationStats(selectedCert, selectedAnswers);
  const displayName = user?.name?.trim() || "Aluno IA Academy";
  const issuers = useMemo(() => Array.from(new Set(interactiveCertificationsCatalog.map(cert => cert.issuer))), []);
  const filteredCertifications = useMemo(() => {
    const normalizedSearch = searchTerm.trim().toLocaleLowerCase();
    return interactiveCertificationsCatalog.filter(cert => {
      const matchesSearch = !normalizedSearch || [cert.title, cert.issuer, cert.description, ...cert.skillsCovered].join(" ").toLocaleLowerCase().includes(normalizedSearch);
      return matchesSearch && (levelFilter === "todos" || cert.level === levelFilter) && (issuerFilter === "todos" || cert.issuer === issuerFilter);
    });
  }, [issuerFilter, levelFilter, searchTerm]);

  useEffect(() => {
    try { window.localStorage.setItem("ia-academy-interactive-certification-progress", JSON.stringify(answerHistory)); } catch { /* progresso preservado na sessão */ }
  }, [answerHistory]);

  useEffect(() => {
    if (filteredCertifications.length > 0 && !filteredCertifications.some(cert => cert.id === selectedCert.id)) {
      setSelectedCert(filteredCertifications[0]); setCurrentQuestionIndex(0); setShowResults(false);
    }
  }, [filteredCertifications, selectedCert.id]);

  useEffect(() => {
    if (!celebration) return;
    const timer = window.setTimeout(() => setCelebration(null), 4200);
    return () => window.clearTimeout(timer);
  }, [celebration]);

  const handleSelectOption = (optionIndex: number) => {
    setAnswerHistory(prev => ({ ...prev, [selectedCert.id]: { ...(prev[selectedCert.id] ?? {}), [currentQuestionIndex]: optionIndex } }));
    setShowResults(false);
  };

  const handleNext = () => {
    if (currentQuestionIndex < selectedCert.quiz.length - 1) { setCurrentQuestionIndex(prev => prev + 1); return; }
    const stats = getCertificationStats(selectedCert, selectedAnswers);
    const wasCompleted = getCertificationStats(selectedCert, answerHistory[selectedCert.id]).completed && Boolean(completionHistory[selectedCert.id]);
    const wasPerfect = completionHistory[selectedCert.id]?.scorePercentage === 100;
    saveCompletion(selectedCert.id, stats);
    recordStudyActivity({ certificationAttempts: 1 });
    const nextHistory = readCompletionHistory();
    setCompletionHistory(nextHistory);
    setShowResults(true);
    if (stats.scorePercentage === 100 && !wasPerfect) {
      playInterfaceSound("achievement");
      setCelebration({ kind: "perfect", title: "Aproveitamento perfeito!", description: "Você desbloqueou a medalha de excelência neste simulador." });
    } else if (!wasCompleted) {
      playInterfaceSound("achievement");
      setCelebration({ kind: "badge", title: "Nova medalha conquistada!", description: "Sua primeira conclusão foi registrada no seu perfil." });
    }
  };

  const handleReset = () => { setAnswerHistory(prev => ({ ...prev, [selectedCert.id]: {} })); setCurrentQuestionIndex(0); setShowResults(false); };
  const handleSelectCertification = (cert: InteractiveCertification) => { setSelectedCert(cert); setCurrentQuestionIndex(0); setShowResults(false); };
  const completedCount = interactiveCertificationsCatalog.filter(cert => getCertificationStats(cert, answerHistory[cert.id]).completed).length;
  const perfectCount = interactiveCertificationsCatalog.filter(cert => getCertificationStats(cert, answerHistory[cert.id]).completed && getCertificationStats(cert, answerHistory[cert.id]).scorePercentage === 100).length;
  const badges = [
    { id: "first", label: "Primeira Conquista", description: "Conclua seu primeiro simulador", unlocked: completedCount >= 1 },
    { id: "perfect", label: "Aproveitamento Excelente", description: "Acerte todas as questões de um simulador", unlocked: perfectCount >= 1 },
    { id: "specialist", label: "Especialista em IA", description: "Conclua todas as certificações disponíveis", unlocked: completedCount === interactiveCertificationsCatalog.length },
  ];
  const shareUrl = typeof window !== "undefined" ? window.location.href : "https://ialearnhub-ndm4gtgm.manus.space/interactive-certifications";
  const shareText = `Concluí o simulador ${selectedCert.title} na IA Academy com ${selectedStats.scorePercentage}% de aproveitamento.`;
  const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;

  return (
    <div className="container py-12 space-y-12">
      <AnimatePresence>{celebration && <motion.div initial={{ opacity: 0, y: -28, scale: .92 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -16, scale: .96 }} role="status" aria-live="polite" className="fixed inset-x-4 top-24 z-50 mx-auto flex max-w-xl items-center gap-4 rounded-3xl border border-amber-300/50 bg-amber-50 p-5 text-amber-950 shadow-2xl dark:bg-amber-950/95 dark:text-amber-50"><div className="relative"><motion.div animate={{ rotate: [0, -12, 12, 0], scale: [1, 1.18, 1] }} transition={{ duration: .7, repeat: 2 }}><Trophy className="size-10 text-amber-400" /></motion.div><Sparkles className="absolute -right-3 -top-3 size-5 text-fuchsia-400" /></div><div><p className="font-bold">{celebration.title}</p><p className="text-sm opacity-80">{celebration.description}</p></div></motion.div>}</AnimatePresence>
      <div className="space-y-4 max-w-3xl"><div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3.5 py-1 text-sm text-primary font-medium"><Award className="size-4" /> Módulo de Certificação Interativa IA Academy</div><h1 className="text-4xl font-bold tracking-tight md:text-5xl">Simuladores Oficiais de Certificações em IA</h1><p className="text-lg text-muted-foreground">Prepare-se para certificações de IA com trilhas curtas, progresso persistente e feedback imediato. O simulador é uma ferramenta de estudo e não substitui o exame oficial do provedor.</p></div>
      <section aria-labelledby="progress-heading" className="rounded-3xl border border-border bg-card p-6 shadow-sm space-y-6"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-wider text-primary">Minha evolução</p><h2 id="progress-heading" className="text-2xl font-bold">Avance por evidências, não por pressa</h2></div><span className="rounded-full bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">{completedCount} de {interactiveCertificationsCatalog.length} concluídas</span></div><div className="grid gap-4 md:grid-cols-3">{interactiveCertificationsCatalog.map(cert => { const stats = getCertificationStats(cert, answerHistory[cert.id]); return <button type="button" key={cert.id} onClick={() => handleSelectCertification(cert)} className="rounded-2xl border border-border bg-background p-4 text-left transition-colors hover:border-primary/60"><div className="flex items-start justify-between gap-3"><span className="text-sm font-semibold line-clamp-2">{cert.title}</span>{stats.completed ? <CheckCircle2 aria-label="Concluída" className="size-5 shrink-0 text-emerald-400" /> : <span className="text-xs text-muted-foreground">{stats.answeredCount}/{cert.quiz.length}</span>}</div><div className="mt-3 h-2 overflow-hidden rounded-full bg-muted" aria-label={`${stats.percentage}% concluído`}><div className="h-full rounded-full bg-gradient-to-r from-primary to-secondary transition-[width] duration-300" style={{ width: `${stats.percentage}%` }} /></div><p className="mt-2 text-xs text-muted-foreground">{stats.completed ? `${stats.scorePercentage}% de aproveitamento` : `${stats.percentage}% do simulado respondido`}</p></button>; })}</div><div className="flex flex-wrap gap-3" aria-label="Medalhas de progresso">{badges.map(badge => <div key={badge.id} className={`flex items-center gap-3 rounded-2xl border px-4 py-3 ${badge.unlocked ? "border-amber-400/40 bg-amber-400/10" : "border-border bg-background opacity-60"}`}><Trophy className={`size-5 ${badge.unlocked ? "text-amber-300" : "text-muted-foreground"}`} /><div><p className="text-sm font-semibold">{badge.label}</p><p className="text-xs text-muted-foreground">{badge.description}</p></div></div>)}</div></section>
      <div className="grid gap-8 lg:grid-cols-3"><aside className="space-y-4" aria-label="Busca e filtros de certificações"><div className="flex items-center justify-between"><h2 className="text-xl font-bold">Trilhas Certificadas</h2><span className="text-xs text-muted-foreground">{filteredCertifications.length} resultados</span></div><div className="space-y-3 rounded-2xl border border-border bg-card p-4"><label className="relative block"><span className="sr-only">Buscar certificação, provedor ou habilidade</span><Search className="pointer-events-none absolute left-3 top-3 size-4 text-muted-foreground" /><input value={searchTerm} onChange={event => setSearchTerm(event.target.value)} placeholder="Buscar certificação ou habilidade" className="w-full rounded-xl border border-border bg-background py-2.5 pl-9 pr-3 text-sm outline-none transition-colors focus:border-primary" /></label><div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground"><Filter className="size-3.5" /> Filtrar catálogo</div><label className="block text-xs font-medium text-muted-foreground">Nível<select aria-label="Filtrar por nível" value={levelFilter} onChange={event => setLevelFilter(event.target.value)} className="mt-1 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm text-foreground"><option value="todos">Todos os níveis</option><option value="Iniciante">Iniciante</option><option value="Intermediário">Intermediário</option><option value="Avançado">Avançado</option><option value="Especialista">Especialista</option></select></label><label className="block text-xs font-medium text-muted-foreground">Provedor<select aria-label="Filtrar por provedor" value={issuerFilter} onChange={event => setIssuerFilter(event.target.value)} className="mt-1 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm text-foreground"><option value="todos">Todos os provedores</option>{issuers.map(issuer => <option key={issuer} value={issuer}>{issuer}</option>)}</select></label>{(searchTerm || levelFilter !== "todos" || issuerFilter !== "todos") && <Button type="button" variant="outline" size="sm" onClick={() => { setSearchTerm(""); setLevelFilter("todos"); setIssuerFilter("todos"); }} className="w-full">Limpar filtros</Button>}</div>{filteredCertifications.length === 0 ? <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">Nenhuma certificação corresponde aos filtros atuais.</div> : filteredCertifications.map(cert => { const stats = getCertificationStats(cert, answerHistory[cert.id]); return <button type="button" key={cert.id} onClick={() => handleSelectCertification(cert)} className={`w-full cursor-pointer rounded-2xl border p-5 text-left transition-all space-y-3 ${selectedCert.id === cert.id ? "border-primary bg-primary/5 shadow-md" : "border-border bg-card hover:border-primary/50"}`}><div className="flex items-center justify-between"><span className="rounded-full bg-primary/10 px-3 py-0.5 text-xs font-semibold text-primary">{cert.level}</span><span className="text-xs text-muted-foreground flex items-center gap-1"><Trophy className="size-3.5 text-amber-400" /> {cert.durationHours}h est.</span></div><h3 className="font-bold text-lg">{cert.title}</h3><p className="text-xs text-muted-foreground line-clamp-2">{cert.description}</p><div className="flex items-center justify-between text-xs font-semibold text-primary"><span>Emitido por {cert.issuer}</span><span>{stats.percentage}%</span></div><div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${stats.percentage}%` }} /></div></button>; })}</aside>
        <main className="lg:col-span-2 space-y-8"><div className="rounded-3xl border border-border bg-card p-8 shadow-sm space-y-6"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-6"><div><span className="text-xs font-semibold uppercase tracking-wider text-primary">{selectedCert.issuer}</span><h2 className="text-2xl font-bold tracking-tight">{selectedCert.title}</h2></div><a href={selectedCert.officialExamUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline">Exame Oficial <ExternalLink className="size-4" /></a></div><div className="space-y-4"><h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Habilidades Validadas</h3><div className="flex flex-wrap gap-2">{selectedCert.skillsCovered.map(skill => <span key={skill} className="rounded-lg bg-secondary px-3 py-1 text-xs font-medium">{skill}</span>)}</div></div><div className="rounded-2xl border border-primary/20 bg-background p-6 space-y-6"><div className="flex items-center justify-between"><span className="inline-flex items-center gap-2 text-sm font-semibold text-primary"><ShieldCheck className="size-5" /> Simulador Prático de Exame</span>{!showResults && <span className="text-xs text-muted-foreground">Questão {currentQuestionIndex + 1} de {selectedCert.quiz.length}</span>}</div>{!showResults ? <div className="space-y-6"><h4 className="text-lg font-semibold">{currentQuestion.question}</h4><div className="space-y-3">{currentQuestion.options.map((option, optIdx) => { const isSelected = selectedAnswers[currentQuestionIndex] === optIdx; return <button key={option} type="button" onClick={() => handleSelectOption(optIdx)} className={`w-full text-left rounded-xl border p-4 transition-all text-sm font-medium flex items-center justify-between ${isSelected ? "border-primary bg-primary/10 text-foreground" : "border-border bg-card hover:bg-secondary/50 text-muted-foreground"}`}><span>{option}</span><span className={`size-4 rounded-full border flex items-center justify-center ${isSelected ? "border-primary bg-primary text-primary-foreground" : "border-border"}`}>{isSelected && <span className="size-2 rounded-full bg-white" />}</span></button>; })}</div><div className="flex justify-between gap-3 pt-4"><span className="text-xs text-muted-foreground self-center">{selectedStats.percentage}% do caminho concluído</span><Button type="button" onClick={handleNext} disabled={selectedAnswers[currentQuestionIndex] === undefined} className="gap-2">{currentQuestionIndex === selectedCert.quiz.length - 1 ? "Ver Resultado" : "Próxima Questão"}<ArrowRight className="size-4" /></Button></div></div> : <div className="space-y-6 text-center py-6"><div className="inline-flex items-center justify-center size-16 rounded-full bg-emerald-500/10 text-emerald-500 mb-2"><CheckCircle2 className="size-8" /></div><h4 className="text-2xl font-bold">Simulado Concluído!</h4><p className="text-muted-foreground max-w-md mx-auto">Você acertou <strong className="text-foreground">{selectedStats.correctCount}</strong> de <strong className="text-foreground">{selectedCert.quiz.length}</strong> questões ({selectedStats.scorePercentage}%).</p><div className="flex flex-wrap justify-center gap-3"><Button type="button" onClick={handleReset} variant="outline" className="gap-2"><RotateCcw className="size-4" /> Refazer Simulador</Button><Button type="button" onClick={() => setCertificatePreviewOpen(true)} className="gap-2"><Eye className="size-4" /> Pré-visualizar certificado</Button><a href={linkedinUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-md bg-[#0a66c2] px-4 py-2 text-sm font-semibold text-white transition-opacity hover:opacity-90"><Linkedin className="size-4" /> LinkedIn</a><a href={twitterUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-md bg-foreground px-4 py-2 text-sm font-semibold text-background transition-opacity hover:opacity-90"><Twitter className="size-4" /> X/Twitter</a><a href="/profile" className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2 text-sm font-semibold transition-colors hover:bg-secondary"><UserRound className="size-4" /> Ver meu perfil</a></div></div>}</div></div></main>
      </div>
      <Dialog open={certificatePreviewOpen} onOpenChange={setCertificatePreviewOpen}><DialogContent className="max-w-4xl"><DialogHeader><DialogTitle>Pré-visualização do certificado</DialogTitle><DialogDescription>Confira os dados antes de abrir a versão pronta para impressão em PDF.</DialogDescription></DialogHeader><div className="rounded-2xl bg-indigo-50 p-5 dark:bg-indigo-950/30"><div className="rounded-2xl border-2 border-primary/60 bg-background p-8 text-center shadow-inner md:p-12"><p className="text-xs font-bold uppercase tracking-[0.2em] text-primary">Certificado de conclusão</p><p className="mt-4 text-2xl font-black">IA <span className="text-primary">Academy</span></p><h3 className="mt-6 font-serif text-3xl font-bold">Certificado de Conclusão</h3><p className="mt-4 text-muted-foreground">Certificamos que</p><p className="mt-2 text-3xl font-black text-primary">{displayName}</p><p className="mx-auto mt-4 max-w-xl text-muted-foreground">concluiu o simulador <strong className="text-foreground">{selectedCert.title}</strong> com {selectedStats.scorePercentage}% de aproveitamento.</p><span className="mt-6 inline-flex rounded-full bg-primary/10 px-4 py-2 text-sm font-bold text-primary">Aproveitamento: {selectedStats.scorePercentage}%</span></div></div><DialogFooter><Button type="button" variant="outline" onClick={() => setCertificatePreviewOpen(false)}>Fechar pré-visualização</Button><Button type="button" onClick={() => createCertificatePdf(selectedCert, displayName, selectedStats.scorePercentage)} className="gap-2"><Download className="size-4" /> Baixar certificado em PDF</Button></DialogFooter></DialogContent></Dialog>
    </div>
  );
}
